# UI primitives (design system)

Editorial, clean, subtle borders, restrained shadows. Not a copy of Kaskus/X/Threads.
