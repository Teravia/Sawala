# Layout components

Three-column desktop layout: left navigation, central discussion, right context/profile.
Mobile-first responsive. Light background, purple accent. See /docs/REFACTOR.md Phase 11.
