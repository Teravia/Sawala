# Module: monetization

Community Pro, Premium, Business accounts, ads (post-MVP).

See `/docs/PRD.md`, `/docs/BUSINESS-RULES.md`, and `/docs/ARCHITECTURE.md` for full spec.
