# API routes

Route handlers only. Delegate all logic to `src/modules/*` services —
no business logic or direct DB access here.
