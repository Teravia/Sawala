# Security tests
Authorization, privilege escalation, rate limits, injection, session abuse, file upload, moderation bypass.
